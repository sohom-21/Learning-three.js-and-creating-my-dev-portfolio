import bpy

meuObjeto = bpy.context.active_object
imagemOutput = '/Users/titopetri/Desktop/' + 'wireframe_' + meuObjeto.name +'.png'
minhaGeometria = meuObjeto.data
dimensoesDaImagem = 256
mapaUVMap = 'UVMap'

minhaImagem = bpy.data.images.new('UVLayout', width = dimensoesDaImagem, height = dimensoesDaImagem)
minhaGeometria.uv_layers.active = minhaGeometria.uv_layers[mapaUVMap]

bpy.ops.object.mode_set(mode = 'OBJECT')
meuObjeto.select_set(True)

bpy.ops.object.mode_set(mode = 'EDIT')
bpy.ops.uv.select_all(action = 'SELECT')

bpy.ops.uv.export_layout(filepath = imagemOutput, size = (dimensoesDaImagem, dimensoesDaImagem))
bpy.data.images.remove(minhaImagem)
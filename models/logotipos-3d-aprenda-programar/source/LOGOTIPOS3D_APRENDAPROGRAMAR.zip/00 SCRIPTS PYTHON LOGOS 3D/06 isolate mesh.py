import bpy

for obj in bpy.context.scene.objects:
    obj.select_set(not obj.select_get())

bpy.ops.object.delete() 
 
meuObjeto = bpy.context.active_object
imagemOutput = '/Users/titopetri/Desktop/' + meuObjeto.name +'.blend'
 
bpy.ops.wm.save_as_mainfile(filepath = imagemOutput)
 
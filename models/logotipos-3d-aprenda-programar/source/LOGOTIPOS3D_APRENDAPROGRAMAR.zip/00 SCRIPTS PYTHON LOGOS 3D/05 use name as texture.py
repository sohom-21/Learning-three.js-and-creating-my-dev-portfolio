import bpy
meuObjeto = bpy.context.active_object
imagemOutput = '/Users/titopetri/Desktop/' + meuObjeto.name +'.png'
obj = bpy.context.active_object
new_material = bpy.data.materials.new(name = "MAPA" + meuObjeto.name)
obj.data.materials.append(new_material)
new_material.use_nodes = True
new_material.node_tree.nodes.clear()

diffuse_node = new_material.node_tree.nodes.new(type='ShaderNodeBsdfDiffuse')
#principled_node = new_material.node_tree.nodes.new(type='ShaderNodeBsdfPrincipled')
image_texture_node = new_material.node_tree.nodes.new(type='ShaderNodeTexImage')


image_texture_node.image = bpy.data.images.load(imagemOutput)
new_material.node_tree.links.new(image_texture_node.outputs["Color"], diffuse_node.inputs["Color"])
output_node = new_material.node_tree.nodes.get("Material Output")
output_node = new_material.node_tree.nodes.new(type='ShaderNodeOutputMaterial')
new_material.node_tree.links.new(diffuse_node.outputs["BSDF"], output_node.inputs["Surface"])
 
import bpy

materiais = bpy.data.materials


"""
for m in materiais:
    bpy.data.materials.remove(m) 
"""
slots = bpy.context.object.material_slots

for s in slots:
    bpy.context.object.active_material_index = 0
    bpy.ops.object.material_slot_remove() 
import bpy

bpy.context.scene.render.engine = 'CYCLES'
bpy.context.scene.cycles.preview_samples = 8
bpy.context.scene.cycles.samples = 64 
dimensoesDaImagem = 256
obj = bpy.context.active_object

image_name = obj.name + '_BakedTexture'
img = bpy.data.images.new(image_name,dimensoesDaImagem,dimensoesDaImagem)

for mat in obj.data.materials:
    mat.use_nodes = True 
    nodes = mat.node_tree.nodes
    texture_node =nodes.new('ShaderNodeTexImage')
    texture_node.name = 'Bake_node'
    texture_node.select = True
    nodes.active = texture_node
    texture_node.image = img
    
bpy.context.view_layer.objects.active = obj
bpy.ops.object.bake(type='COMBINED', save_mode='EXTERNAL')

meuObjeto = bpy.context.active_object
imagemOutput = '/Users/titopetri/Desktop/' + '' + meuObjeto.name +'.png'

img.save_render(filepath = imagemOutput)
     
for mat in obj.data.materials:
    for n in mat.node_tree.nodes:
        if n.name == 'Bake_node':
            mat.node_tree.nodes.remove(n)
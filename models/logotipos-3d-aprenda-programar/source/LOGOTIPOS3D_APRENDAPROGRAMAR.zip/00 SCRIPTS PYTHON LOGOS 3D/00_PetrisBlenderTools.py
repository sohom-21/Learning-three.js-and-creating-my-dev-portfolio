import bpy

# Função para ação do botão 1
def acao_botao_1(self, context):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.light_add(type='SUN')

# Função para ação do botão 2
def acao_botao_2(self, context):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.light_add(type='POINT')

# Função para ação do botão 3
def acao_botao_3(self, context):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.light_add(type='SPOT')

# Função para ação do botão 4
def acao_botao_4(self, context):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.light_add(type='AREA')

# Função para ação do botão 5
def acao_botao_5(self, context):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.light_add(type='HEMI')

# Função para ação do botão 6
def acao_botao_6(self, context):
    # Adicione aqui a ação desejada para o botão 6
    pass

# Função para ação do botão 7
def acao_botao_7(self, context):
    # Adicione aqui a ação desejada para o botão 7
    pass

# Função para ação do botão 8
def acao_botao_8(self, context):
    # Adicione aqui a ação desejada para o botão 8
    pass

# Função para ação do botão 9
def acao_botao_9(self, context):
    # Adicione aqui a ação desejada para o botão 9
    pass

# Criação do painel
class SimpleMenuPanel(bpy.types.Panel):
    bl_label = "Menu Simples"
    bl_idname = "PT_Simple_Menu"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Ferramentas'

    def draw(self, context):
        layout = self.layout

        # Botão 1
        layout.operator("wm.acao_botao_1", text="Botão 1")

        # Botão 2
        layout.operator("wm.acao_botao_2", text="Botão 2")

        # Botão 3
        layout.operator("wm.acao_botao_3", text="Botão 3")

        # Botão 4
        layout.operator("wm.acao_botao_4", text="Botão 4")

        # Botão 5
        layout.operator("wm.acao_botao_5", text="Botão 5")

        # Botão 6
        layout.operator("wm.acao_botao_6", text="Botão 6")

        # Botão 7
        layout.operator("wm.acao_botao_7", text="Botão 7")

        # Botão 8
        layout.operator("wm.acao_botao_8", text="Botão 8")

        # Botão 9
        layout.operator("wm.acao_botao_9", text="Botão 9")

# Registro das funções e do painel
def register():
    bpy.utils.register_class(SimpleMenuPanel)
    bpy.utils.register_class(acao_botao_1)
    bpy.utils.register_class(acao_botao_2)
    bpy.utils.register_class(acao_botao_3)
    bpy.utils.register_class(acao_botao_4)
    bpy.utils.register_class(acao_botao_5)
    bpy.utils.register_class(acao_botao_6)
    bpy.utils.register_class(acao_botao_7)
    bpy.utils.register_class(acao_botao_8)
    bpy.utils.register_class(acao_botao_9)

def unregister():
    bpy.utils.unregister_class(SimpleMenuPanel)
    bpy.utils.unregister_class(acao_botao_1)
    bpy.utils.unregister_class(acao_botao_2)
    bpy.utils.unregister_class(acao_botao_3)
    bpy.utils.unregister_class(acao_botao_4)
    bpy.utils.unregister_class(acao_botao_5)
    bpy.utils.unregister_class(acao_botao_6)
    bpy.utils.unregister_class(acao_botao_7)
    bpy.utils.unregister_class(acao_botao_8)
    bpy.utils.unregister_class(acao_botao_9)

if __name__ == "__main__":
    register()





Clear Objects Materials
Clear ALL SCENE MATERIALS
Export UV Layout
Bake Diffuse Combined
Bake Ambient Occlusion
Bake Metal
Bake Rough
Replace Material AOC
Use name as Texture
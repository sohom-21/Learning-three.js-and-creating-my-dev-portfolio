import bpy

materiais = bpy.data.materials
for m in materiais:
    bpy.data.materials.remove(m)

slots = bpy.context.object.material_slots
for s in slots:
    bpy.context.object.active_material_index = 0
    bpy.ops.object.material_slot_remove()

obj = bpy.context.active_object
new_material = bpy.data.materials.new(name="AOC_Material")
new_material.use_nodes = True
new_material.node_tree.nodes.clear()
ao_node = new_material.node_tree.nodes.new(type='ShaderNodeAmbientOcclusion')
diffuse_node = new_material.node_tree.nodes.new(type='ShaderNodeBsdfDiffuse')
new_material.node_tree.links.new(ao_node.outputs["Color"], diffuse_node.inputs["Color"])
output_node = new_material.node_tree.nodes.new(type='ShaderNodeOutputMaterial')
new_material.node_tree.links.new(diffuse_node.outputs["BSDF"], output_node.inputs["Surface"])
obj.data.materials.append(new_material)